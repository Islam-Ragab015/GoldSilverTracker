class States {}

class InitialState extends States {}

class GetGoldPriceState extends States {}

class GetSilverPriceState extends States {}
